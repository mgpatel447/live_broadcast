// Dart imports:
import 'dart:math' as math;

/// Note that the userID needs to be globally unique,
final String localUserID = math.Random().nextInt(10000).toString();

const int kAppId = 878268490;
const String AppSign = "eb869735592c84a313a1377cf475603237e9c4d34dcc122005790d0a0cd5ee93";