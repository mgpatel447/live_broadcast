package com.example.agora_broadcast

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
